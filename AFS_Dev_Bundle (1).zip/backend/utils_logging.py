print('Logging util placeholder')
